<template>
    <div class="absolute inset-0 z-30"
    :style="`background: linear-gradient(rgba(255, 255, 255, 1) 20%, rgba(255,255,255,0.3) 100%);`"></div>
</template>
